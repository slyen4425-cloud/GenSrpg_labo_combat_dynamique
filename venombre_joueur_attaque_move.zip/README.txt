Deux animations approuvees dans la conversation, 8 frames chacune.
animation_1_validee: preview_attaque_scorpion_bords_corriges.webp
animation_2_validee: preview_attaque_scorpion_artefacts_corriges.webp
PNG 512x512 RGBA, pas de regeneration artistique.
