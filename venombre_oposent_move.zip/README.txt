Scorpion - animation course corrigee et validee, 8 frames PNG RGBA 512x512. Preview WEBP. Ne pas remplacer les autres animations.
