#!/usr/bin/env python3
"""Install a self-contained GenSRPG icon pack into an ISOLATED WORK BRANCH.
Dry-run by default; never touches gameplay code, and never overwrites assets.
"""
from __future__ import annotations
import argparse, hashlib, json, os, shutil, subprocess, sys, tempfile
from pathlib import Path

PACK = Path(__file__).resolve().parent
REL_CATALOG = 'data/assets/catalog/global-visual-assets.v1.json'

def git(repo, *args):
    return subprocess.check_output(['git','-C',str(repo),*args], text=True, stderr=subprocess.STDOUT).strip()

def readj(p): return json.loads(p.read_text(encoding='utf8'))

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', required=True, type=Path, help='Path to a checked-out work branch based on global-assets')
    parser.add_argument('--apply',action='store_true',help='Write after collision tests; otherwise preview only')
    args=parser.parse_args()
    repo=args.repo.resolve()
    assert repo.is_dir() and (repo/'.git').exists(), 'Repository must be a local Git working tree (not a bare directory)'
    branch=git(repo, 'branch','--show-current')
    assert branch.startswith('work/'), f'Refusing branch {branch!r}: use a dedicated work/ branch, NOT global-assets or main'
    assert not git(repo,'status','--porcelain'), 'Refusing a dirty worktree. Commit/stash other changes first.'
    catalog_path=repo/REL_CATALOG
    assert catalog_path.is_file(), f'Missing canonical catalog {REL_CATALOG}'
    catalog=readj(catalog_path)
    assert catalog.get('storage',{}).get('branch')=='global-assets','Wrong catalog owner'
    assert catalog.get('counts',{}).get('assets')==len(catalog.get('assets',[])),'Catalog counts are inconsistent'
    assert catalog.get('counts',{}).get('icons')==sum(x.get('assetType')=='icon' for x in catalog['assets']),'Icon counter mismatch'
    entries=readj(PACK/'catalog/ui-icon-catalog-entries.v1.json')
    manifest=readj(PACK/'catalog/ui-icon-manifest.v1.json')['assets']
    assert len(entries)==len(manifest)==18
    old_ids={a['id'] for a in catalog['assets']}
    old_paths={a.get('resource',{}).get('file') for a in catalog['assets']}
    assert len(old_ids)==len(catalog['assets']), 'Existing catalog has duplicate IDs'
    ids={e['id'] for e in entries}
    paths={e['resource']['file'] for e in entries}
    assert len(ids)==len(paths)==18
    assert old_ids.isdisjoint(ids), f'Existing asset IDs collide: {old_ids & ids}'
    assert old_paths.isdisjoint(paths), f'Existing paths collide: {old_paths & paths}'
    copy_items=[]
    for r in manifest:
        assert r['assetId'] in ids
        for key in ('master','runtime'):
            rel = Path(r[key])
            assert not rel.is_absolute() and '..' not in rel.parts and str(rel).startswith('assets/library/core/icons/ui/')
            inp=PACK/rel;out=repo/rel
            assert inp.is_file(),f'Missing source {inp}'
            assert not out.exists(),f'Destination already exists: {out}'
            copy_items.append((inp,out))
        runtime=PACK/r['runtime']
        assert hashlib.sha256(runtime.read_bytes()).hexdigest()==r['sha256Runtime'],f'Hash mismatch {runtime}'
    assert len(copy_items)==36
    existing_bytes=catalog_path.read_bytes()
    for a in entries:catalog['assets'].append(a)
    catalog['counts']['assets']=len(catalog['assets'])
    catalog['counts']['icons']=sum(x.get('assetType')=='icon' for x in catalog['assets'])
    print(f'Validated: {len(entries)} NEW IDs, {len(copy_items)} NEW files, catalog {len(catalog["assets"])} assets/{catalog["counts"]["icons"]} icons')
    print(f'Target: {repo}  Branch: {branch}  Applying: {args.apply}')
    if not args.apply:
        print('DRY RUN: no changes made. To apply, re-run with --apply after the branch/checkpoint review.')
        return 0
    created=[];tmp=None
    try:
        for inp,out in copy_items:
            out.parent.mkdir(parents=True,exist_ok=True)
            with out.open('xb') as f:
                created.append(out)
                with inp.open('rb') as src:shutil.copyfileobj(src,f)
        fd,tmp=tempfile.mkstemp(prefix='.global-visual-assets.v1.',suffix='.tmp',dir=catalog_path.parent)
        with os.fdopen(fd,'wb') as f:
            f.write((json.dumps(catalog,ensure_ascii=False,indent=2)+'\n').encode('utf8'))
        assert catalog_path.read_bytes()==existing_bytes, 'Catalog changed during install; aborting.'
        os.replace(tmp,catalog_path)
        print('APPLIED to work branch only. Run CI; do not merge until approved GREEN and checkpoint.')
        return 0
    except Exception:
        if tmp and Path(tmp).exists():Path(tmp).unlink()
        for path in reversed(created):
            if path.exists():path.unlink()
        raise

if __name__=='__main__':
    try:sys.exit(main())
    except Exception as e:
        print(f'BLOCKED (no safe install): {e}',file=sys.stderr)
        sys.exit(1)
