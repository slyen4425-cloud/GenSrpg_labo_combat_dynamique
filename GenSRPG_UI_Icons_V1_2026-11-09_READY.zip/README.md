# GenSRPG — Icônes d'interface V1 — lot non intrusif

Ce pack contient **18 médaillons approuvés** sans texte sur fond transparent, découpés individuellement :
- **4 statistiques réelles** : santé/PV (`health`), puissance physique (`physical`), défense (`defense`), vitesse (`speed`).
- **12 statistiques élémentaires réelles** : feu (`fire`), eau (`water`), électricité (`electric`), glace (`glace`), poison (`poison`), terre (`earth`), air (`air`), nature (`nature`), acier (`acier`), lumière (`light`), ombre (`shadow`), esprit (`esprit`).
- **2 symboles d'interface uniquement** : énergie (`energy`) et endurance (`endurance`). Ces deux notions ne sont pas de nouvelles statistiques du registre de progression.

## Structure

`assets/library/core/icons/ui/stats/` — 4 icônes statistiques
`assets/library/core/icons/ui/element/` — 12 icônes élémentaires
`assets/library/core/icons/ui/symbol/` — 2 pictogrammes d'interface
`catalog/ui-icon-catalog-entries.v1.json` — **18 ajouts seulement** au catalogue canonique, jamais une copie du catalogue complet
`catalog/ui-icon-bindings.v1.json` — correspondance par identifiant réel du registre ; non activée
`catalog/ui-icon-manifest.v1.json` — provenance et empreintes SHA-256
`previews/contact_sheet.png` — planche de vérification
`tests/check_pack.py` — contrôle autonome du ZIP et des 18 fichiers
`tools_install_pack.py` — import local avec prévisualisation (dry-run), collision checks, arrêt si arbre Git non propre ou si mauvaise branche; applique uniquement avec `--apply`
`catalog/ui-icon-resolver-example.mjs` — exemple sans effet de bord pour la couche de présentation

Chaque icône possède un maître PNG 256×256 transparent et une version runtime WebP 128×128 transparente.

## Mode d'intégration sans conflits

1. Travailler dans un lot isolé basé sur le SHA actuel de `global-assets` ; respecter la charte, les checkpoints et une seule autorité des assets.
2. Vérifier l'absence de collision des 18 IDs ET chemins sur `global-assets`; ne jamais remplacer un fichier préexistant.
3. Copier **uniquement** les 18 WebP runtime dans la bibliothèque canonique ; conserver les maîtres PNG dans le même dossier si la règle de provenance l'autorise.
4. Utiliser le script `python tools_install_pack.py --repo /chemin/vers/clone` **sans `--apply`** pour vérifier collisions/compteurs; puis `--apply` dans une branche `work/` propre après checkpoint. Le script ajoute les **18 entrées** au seul catalogue `data/assets/catalog/global-visual-assets.v1.json` avec les compteurs recalculés ; aucune duplication de ce catalogue.
5. Valider les SHA-256 et le test des chemins; CI GREEN + checkpoint, puis publier `global-assets` uniquement.
6. Dans un lot séparé côté application (éditeur/rendu), consommer les `assetId` depuis `ui-icon-bindings.v1.json` **sans toucher aux valeurs de statistiques ou aux règles de combat**.
7. Ajouter repli visuel pour PWA offline, versionner le cache, vérifier Android et PC.

**Aucune substitution automatique** des pictogrammes existants; pas de publication vers `main`, pas de duplication du labo, pas de nouvelles stats, pas de modification des sauvegardes, pas de changement de gameplay.

Périmètre PWA : la bibliothèque est partagée comme origine des fichiers, mais son adoption par d'autres modules que Capture reste un choix explicite au niveau application ; ces modules ne doivent pas changer automatiquement.

## Notes de qualité

La seconde planche de génération présentait des halos colorés reliant les médaillons ; ces halos ont été masqués pendant la découpe, sans toucher au cercle et à l'illustration centrale. La planche `previews/contact_sheet.png` permet une revue avant publication.
