from pathlib import Path
from PIL import Image
import hashlib,json,sys
base=Path(__file__).resolve().parents[1]
data=json.loads((base/'catalog/ui-icon-manifest.v1.json').read_text(encoding='utf8'))
bindings=json.loads((base/'catalog/ui-icon-bindings.v1.json').read_text(encoding='utf8'))
entries=json.loads((base/'catalog/ui-icon-catalog-entries.v1.json').read_text(encoding='utf8'))
assert len(data['assets'])==18 and len(entries)==18
assert len(bindings['statIconsByRegistryId'])==16
assert len(bindings['uiOnlySymbols'])==2
assert len({a['assetId'] for a in data['assets']})==18
assert len({e['resource']['file'] for e in entries})==18
for r in data['assets']:
    master=base/r['master'];runtime=base/r['runtime']
    assert master.is_file() and runtime.is_file()
    assert hashlib.sha256(runtime.read_bytes()).hexdigest()==r['sha256Runtime']
    with Image.open(master) as x:
        assert x.format=='PNG' and x.mode=='RGBA' and x.size==(256,256)
        al=x.getchannel('A')
        assert al.getextrema()[0]==0 and al.getextrema()[1]>150
    with Image.open(runtime) as x:
        assert x.format=='WEBP' and x.size==(128,128)
        assert 'A' in x.getbands(),(runtime,x.getbands())
        al=x.getchannel('A')
        assert al.getextrema()[0]==0 and al.getextrema()[1]>150
    matches=[e for e in entries if e['id']==r['assetId']]
    assert len(matches)==1
    assert matches[0]['resource']['file']==r['runtime'].split('assets/library/',1)[1]
print('OK: 18 IDs distincts, 16 liaisons statistiques existantes, 2 symboles seuls, 18 PNG + 18 WebP RGBA, SHA-256 valides')
