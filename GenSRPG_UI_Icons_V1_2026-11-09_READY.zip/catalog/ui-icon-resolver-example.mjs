// Exemple sans effet de bord : l'application choisit quand afficher les icônes.
// Ne jamais utiliser ces chemins comme source de vérité métier ou remplacer le registre de stats.
// Injection de l'URL catalogue et du resolver d'assets par le consommateur.

export function makeUiStatIconLookup({ bindings, resolveAssetUrl, fallbackUrl = null }) {
  if (!bindings || !bindings.statIconsByRegistryId || typeof resolveAssetUrl !== 'function') {
    throw new TypeError('Missing canonical bindings or asset resolver');
  }
  return function uiIconForRegistryStat(statId) {
    const assetId = bindings.statIconsByRegistryId[statId];
    if (!assetId) return fallbackUrl;
    return resolveAssetUrl(assetId) || fallbackUrl;
  };
}
