Monster Capture / Nouveau lot TEST - Racines perforantes

8 véritables frames successives PNG RGBA 512x512.
Séquence de croissance, rupture puis dissipation.
Pas de nouveaux assetIds; pas de publication dans GitHub.
Important : la source était blanche; transparence reconstruite techniquement.
Vérifier les halos et l'animation avant validation.
