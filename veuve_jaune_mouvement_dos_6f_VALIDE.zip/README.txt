VEUVE JAUNE — MOUVEMENT DOS (6 frames) — VALIDATION ARTISTIQUE 23/11/2026

Fichiers :
 - sources/animation_validee_originale.gif : animation strictement inchangée et validée par auteur.
 - sources/modele_dos_original.png : modèle source original, intact.
 - frames/ : 6 PNG RGBA transparents 512x512, dans l’ordre.
 - atlas/ : atlas horizontal 3072x512.
 - previews/ : GIF lisible sur fond sombre, WebP animé transparent et contact sheet.
 - manifest.json : traçabilité et résultat des vérifications.

Modifications techniques : détourage du fond blanc et même réduction de cadrage 420/512 pour toutes les poses, afin de garder les pattes dans les cases.
Aucun raccord GitHub/jeu effectué dans ce ZIP.
