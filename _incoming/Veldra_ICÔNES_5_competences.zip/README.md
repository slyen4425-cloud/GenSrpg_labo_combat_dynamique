# Pack visuels Veldra — 18/11/2026

Cinq compétences officielles : Plume solaire, Percée d’aurore, Égide du zénith, Rayon cardinal, Relève céleste.

- icones/png_512 : cinq images maîtres PNG 512², cadre fantasy avec fond travaillé.
- icones/webp_128 : cinq icônes WebP 128² runtime.
- sprites/frames_256 : quatre-vingts frames PNG RGBA transparentes 256².
- sprites/planches_4x4 : cinq planches PNG RGBA 1024² (4×4).
- sprites/runtime_webp_strip : cinq bandes WebP RGBA 4096×256, 16 frames.
- sprites/previews_gif : animations lisibles pour validation.
- MANIFEST_VELDRA.json : identifiants proposés, checksums, informations de provenance.

IMPORTANT : pack **candidat**, hors GitHub pour l'instant. Les plans source proviennent d'une planche composite et le fond des sprites a été retiré automatiquement (alpha); inspecter les bords dans la prévisualisation avant de valider. Ne pas présumer de leur adoption par la bibliothèque tant que les médias ne sont pas publiés sur global-assets et que le CI/raccord ne sont pas certifiés.
