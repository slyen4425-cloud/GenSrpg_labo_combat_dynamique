# GOLEM MOUSSU DOS — 12 frames mouvement + attaque

Statut : **PREVIEW POUR VALIDATION**. Aucune publication GitHub ni affectation automatique au combat.

- Source : modèle dos transmis par l’auteur et les deux planches corrigées.
- Movement : 12 PNG 512×512 transparents, boucle, 90 ms / image.
- Attack : 12 PNG 512×512 transparents, lecture unique, 110 ms / image.
- Deux atlas WebP sans perte 4608×384, une case 384×384 par frame.
- GIF de preview et WebP animés transparents ; 2 planches de prévisualisation espacées.
- Pas de transformation générative additionnelle, découpe des 12 poses originales.
- Éventuelles limites artistiques des planches sources à vérifier dans les GIF : déformation locale d’une patte et changement d’orientation au mouvement.
- Pour l'attaque : pieds arrière conservant leur place, buste qui se soulève, pattes avant qui frappent le sol.
