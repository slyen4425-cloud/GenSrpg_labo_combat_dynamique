ATTAQUE SOUTERRAINE - Pack FX

- 3 animations
  1) start / creusement_depart
  2) travel / sillon_trajet
  3) impact / emergence_impact
- 20 frames par animation
- PNG transparents 512x512
- previews PNG + GIF
- exemple de reglages pour la section attaque souterraine
