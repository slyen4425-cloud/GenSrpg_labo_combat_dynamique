Package validé Ailevent dos / côté joueur.
- MOUVEMENT_10F : version finale avec suppression des anciennes frames 10 et 11, contours nettoyés.
- ATTAQUE_12F : animation validée.
- MODELE_JOUEUR_REMPLACEMENT : image à utiliser pour remplacer le modèle joueur.
