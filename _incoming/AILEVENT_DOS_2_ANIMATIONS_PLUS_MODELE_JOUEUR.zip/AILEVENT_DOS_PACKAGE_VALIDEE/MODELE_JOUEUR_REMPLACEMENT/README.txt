Remplacer le modèle joueur / dos par cette image validée par l’utilisateur : ailevent_player_model.png
