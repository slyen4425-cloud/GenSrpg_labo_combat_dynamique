Pack de deux animations approuvees : course et attaque, 8 frames chacune.
PNG RGBA 512x512. Previews WebP incluses.
Importer dans le repertoire _incoming du depot laboratoire combat sur la branche de travail appropriee.
Ne pas modifier les animations existantes sans validation.
