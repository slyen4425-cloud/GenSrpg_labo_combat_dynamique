FACE : course + attaque, 8 frames chacune, déjà déposées sur GitHub.
DOS : course 8 frames validée avec réserves de cadrage des pattes.
ATTAQUE DOS : pas encore créée.
Ne pas substituer la vue dos à la vue face.
