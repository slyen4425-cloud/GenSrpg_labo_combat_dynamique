Ephemus — IDLE, vol stationnaire.
12 PNG RGBA par vue, 512 x 512, 12 FPS, boucle.
Les PNG sont les octets exacts du rendu validé en revue; aucune retouche ni conversion GIF.
Les aperçus APNG conservent les pixels et l'alpha. Les projets .rigby sont les sources modifiables.
Le petit fragment détaché sur l'aile gauche DOS préexiste dans le maître. Aucun raccord au catalogue ou au jeu effectué.
Source GitHub Actions 45592127804, artefact 15011248045.
