ÉPHÉMUS — 5 icônes originales pour le Labo Combat GenSRPG

Chaque icône est fournie en PNG RGBA transparent 512×512 (game-ready) et en haute résolution 1254×1254.
Ces fichiers sont des livrables de création, pas encore raccordés au catalogue GitHub global-assets.
Les noms sont alignés sur les IDs de compétences de la PR #334.
