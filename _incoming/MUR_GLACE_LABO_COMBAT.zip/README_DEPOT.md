# Mur de glace — remplacement visuel stable (1 novembre 2026)

Asset officiel cible : `pack:capture:sprite-mur-glace-arcanique-01` (celui référencé par `mur_de_glace`).

Le ZIP reprend exactement les chemins de la branche `global-assets` pour remplacer les 12 PNG, le WebP horizontal 6144×512, le GIF d’aperçu et le manifest de cette variante. Ne pas créer un deuxième ID ou un deuxième catalogue.

**Important** : ne pas fusionner les fichiers sur gh-pages ou main ; uploader sur `global-assets`, dans le chemin `assets/library/capture/sprites/skills/murs_glace/mur_glace_arcanique/`. Conserver la mécanique, PV et collisions inchangés. Le serveur de l’application devrait augmenter la révision de cache `GLOBAL_VISUAL_LIBRARY.revision` au moment de la mise en ligne pour forcer la nouvelle texture.

La frame 12 contient un mur intact, qui reste affiché tant que le mur possède des PV. Les 11 précédentes montrent sa formation. L’angle reste 2.5D / trois-quarts légèrement plongeant.

**Découpe vérifiée** : extraction par composantes connexes alpha élevée, source de 1448×1086, 12 modèles séparés, remontage 512×512 sur ancrage commun ; marge officielle portée de 32 à 42 px minimum (+30 %) ; le rapport réel est dans `validation_marges.json`. Ne jamais couper directement la grille générée sans vérifier les contours.

L’upload de ce ZIP sur GitHub est nécessaire pour que les joueurs voient le remplacement ; le ZIP lui-même ne modifie pas automatiquement le dépôt.
