# Loup volcanique — import des animations face (12 frames)

Deux animations **validées par l’auteur** le 21 octobre 2026 : course (`movement`, en boucle) et attaque (`attack`, une lecture).

Les PNG sont conservés strictement à l’identique des archives approuvées ; aucune nouvelle génération ni retouche des modèles.

- 12 images RGBA 512x512 par animation, noms déterministes.
- 2 atlases WebP RGBA (sprite-strip 4608x384) pour le catalogue Capture.
- 2 aperçus GIF, 2 manifestes avec SHA-256 des sources, des PNG et des atlases.
- Mise à jour du catalogue uniquement après import réel dans le dépôt.

**Important :** sur certains PNG de course, des pixels transparence/non-transparent arrivent jusqu'au bord du carré de 512 px. La marge minimum globale mesurée est 0 px : ne pas prétendre à une sécurité de 40 px de marge interne dans la source. La validation visuelle par l’auteur porte sur les aperçus, pas sur l’absence absolue de pixels en bordure.

Les assets officiels `runtime/*`, les vues dos/joueur et les identifiants préexistants ne doivent pas être modifiés.
