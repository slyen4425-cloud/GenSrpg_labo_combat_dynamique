ÉPHÉMUS — 5 planches sprites VFX (4×4, 16 frames).

Format : PNG RGBA transparent, grille 4×4, planche 1024×1024, frames 256×256 (de gauche à droite puis ligne suivante).
Chaque frame est aussi livrée en PNG individuel 256×256 pour permettre import dans l’éditeur.
NOTES : les frames sont des créations artistiques. Leur intégration à la bibliothèque officielle des assets et leur synchronisation au combat restent à tester avant publication.
