GOLEM MOUSSU — 2 ANIMATIONS FACE 12 FRAMES — SOURCE USER APPROVED 2026-10-21

Movement: 12 PNG RGBA 512x512, 85ms, loop; attack: 12 PNG RGBA 512x512, 100ms, once.
Atlas: WebP sprite-strip horizontal, 12x384, RGBA. Base art from earlier user-visible sheets; technical crop repaired for attack foot safety.
DO NOT OVERWRITE runtime original view/character/engine. Register 2 unique IDs in Global Assets catalog.
GitHub: assets/library/capture/creatures/golem_moussu/animations/{movement,attack}/face/{frames,atlases,previews}.
