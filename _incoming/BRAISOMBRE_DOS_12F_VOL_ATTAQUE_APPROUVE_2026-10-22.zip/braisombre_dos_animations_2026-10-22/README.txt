Braisombre — animations DOS approuvées
Date: 2026-10-22

Contenu:
- BRAISOMBRE_DOS_VOL_12F_APPROUVE_2026-10-22.png
- BRAISOMBRE_DOS_ATTAQUE_12F_APPROUVE_2026-10-22.png

Notes:
- 12 frames par planche
- fond transparent RGBA
- planches validées par l'auteur
