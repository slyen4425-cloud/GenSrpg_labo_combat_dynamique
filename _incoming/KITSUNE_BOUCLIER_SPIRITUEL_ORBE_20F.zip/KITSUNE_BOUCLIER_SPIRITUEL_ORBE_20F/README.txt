Bouclier spirituel Kitsune lunaire - orbe / sphère complète

20 frames PNG 512x512 transparentes.
Nommage: sprite_skill_kitsune_spirit_shield_01.png à 20.
