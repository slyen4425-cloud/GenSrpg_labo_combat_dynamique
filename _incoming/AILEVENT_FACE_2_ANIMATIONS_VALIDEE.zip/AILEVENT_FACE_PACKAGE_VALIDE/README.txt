Package Ailevent vue de face - validation utilisateur du 2026-10-25.
Contenu :
- planche de vol 12 frames
- planche d'attaque 12 frames
- previews GIF et WebP des deux animations
Note : validation obtenue avec une légère réserve utilisateur.
