Vortex des Abysses — 12 frames 512×512 PNG RGBA.
Version stabilisée approuvée (source : preview_Vortex...).
ATTENTION : le canal alpha a été reconstruit depuis un aperçu RGB sur fond sombre ; contrôle en jeu recommandé pour les fumées et les halos.
