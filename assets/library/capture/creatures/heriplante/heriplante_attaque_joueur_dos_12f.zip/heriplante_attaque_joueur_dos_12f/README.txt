HERIPLANTE — ATTAQUE JOUEUR DOS — 12 FRAMES

Statut : preview validee par le createur le 04-11-2026. Pas encore integree dans le jeu.

frames/       12 frames PNG RGBA transparentes, 512 x 512 px
atlas/        atlas PNG transparent de 4 colonnes x 3 lignes, sans gouttiere
previews/     WebP original de validation (640px), GIF, planche de controle,
              et WebP 512px representatif des frames exportees
reference/    modele DOS fourni par l'auteur, et planche source validee
manifest.json provenance, details et controles

ATTENTION : la frame 01 est identique pixel par pixel a la reference DOS.
Les frames suivantes reprennent les poses de l'aperçu valide, repositionnees
sur un canvas 512x512 sans redessiner la creature.
Le test final de continuite anatomique et le raccord runtime restent a effectuer.

GitHub : depot GenSrpg_labo_combat_dynamique, branche global-assets.
Ne pas remplacer l'actif source officiel existant sans validation du raccord.
