HÉRIPLANTE — ATTAQUE ADVERSAIRE FACE — 12 FRAMES

Archive de la preview artistique validée le 04/11/2026.
12 PNG RGBA 512 × 512 et atlas WebP/PNG, sans fond, preview, modèle source exact en frame 01.
Attention : certains débordements des lianes d’origine et marges de moins de 42 px subsistent. Ce ZIP ne vaut pas certificat de conformité moteur ou CI.
