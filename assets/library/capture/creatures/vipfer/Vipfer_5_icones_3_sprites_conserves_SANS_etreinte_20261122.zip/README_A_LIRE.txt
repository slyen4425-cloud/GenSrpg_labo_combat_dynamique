VIPFER — 5 ICÔNES CONSERVÉES + 3 SPRITES DE CAPACITÉ — 22/11/2026

DANS LE ZIP
- 5 icônes de compétences WebP 128×128, plus leurs masters 512×512.
- 3 planches d'effets de compétences retenues : MORSURE À RESSORT, MUE TRANCHANTE, COURONNE D'ÉCLATS.
- Chaque planche originale 1536×1024 (6 poses 3×2) est préservée octet pour octet dans sprites/sources_originales/.
- 6 images PNG RGBA 512×512 par effet, issues de la planche correspondante. L’export est redimensionné uniformément et posé sur un canevas transparent à marges de 46 px pour éviter les coupes en combat.
- Pour chacune : atlas WebP sans gouttière 6×1, GIF sur fond sombre UNIQUEMENT en prévisualisation, et manifeste d'export.

EXCLUS EXPRESSÉMENT
- Tous les anciens sprites d'ÉTREINTE D'ACIER (silhouettes humaines).
- BROYEUR SERPENTIN (ancienne planche contenant elle aussi une silhouette humaine).
- Toutes les dernières tentatives de recréation de Vipfer / animations du modèle de créature.
- Les effets schématiques du précédent ZIP de prévisualisation.

IMPORTANT
- Ces sprites sont les séquences tirées des planches artistiques retenues; aucun assetId officiel ni import automatique n'a été créé.
- Les 5 nouvelles compétences ne sont PAS encore créées/activées dans le Labo Combat (PR #379 = documentation uniquement, non fusionnée au moment de l'audit).
- Ce paquet est un paquet de sources et de previews pour validation/raccord ultérieur. La validation technique finale en jeu (résolution assetId, collisions, comportement, mobile) reste à faire.
- Les frames n'ont PAS fait l'objet d'un raccord runtime; les GIF ne sont que des previews.
