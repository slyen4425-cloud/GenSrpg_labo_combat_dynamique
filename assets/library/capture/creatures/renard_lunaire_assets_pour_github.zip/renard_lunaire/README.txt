Renard lunaire - assets Monster Capture
Vue FACE: renard_lunaire_face.webp (512x512)
Vue DOS: renard_lunaire_dos.webp (512x512)
Icône: renard_lunaire_icon_384.webp ou _192.webp (WebP, extérieur transparent)
Destination canonique : branche global-assets, assets/library/capture/creatures/renard_lunaire/runtime/
ATTENTION : les entrées manifest-entries.json ne doivent être publiées dans data/assets/catalog/global-visual-assets.v1.json que lorsque les fichiers binaires existent à leur destination.
Les deux vues sont des modèles fixes et ne sont pas des animations 12/20 frames ; le sélecteur animation requiert un atlas multiframe.
