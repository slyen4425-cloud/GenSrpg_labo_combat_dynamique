# Capture — 8 nouvelles icônes de capacités

Assets visuels préexistants, préparés au format WebP 128×128 pour le Labo Combat.

Nouveaux IDs à enregistrer dans le catalogue global, sans remplacer les liaisons de compétences existantes.
