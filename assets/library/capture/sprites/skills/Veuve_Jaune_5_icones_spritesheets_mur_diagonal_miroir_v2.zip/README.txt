VEUVE JAUNE — sprites de compétences et cinq icônes

Contenu :
- icons/ : les 5 compétences officielles, PNG transparents 512x512
- frames/ : 8 images PNG transparentes par animation, tailles uniformes
- sheets/ : spritesheets horizontales 8 frames (rangée unique), PNG RGBA
- previews/ : vrais GIF animés destinés à la validation artistique
- manifest.json : dimensions, cadence, association aux vrais skill IDs

SÉPARATIONS IMPORTANTES
Fil foudroyant : projectile distinct de l'impact.
Toile paralysante : mur apparition distinct de l'animation de boucle.
Morsure neuroélectrique : impact seul, pas de nouveau héros dessiné.
Emprise de soie : projectile distinct du statut de toile EN SURIMPRESSION.
La cible sera la créature du combat ; aucune silhouette humaine n'est dans les images.
Domaine de la Veuve : impact de zone distinct.

Ce ZIP est un lot visuel à valider, PAS une intégration du code GitHub.


MISE À JOUR V2 — MUR DIAGONAL EN MIROIR
Les deux animations toile_paralysante_mur_apparition et toile_paralysante_mur_boucle ont été REMPLACÉES (pas ajoutées en doublon).
Les 8 frames de chacune sont en perspective diagonale 3/4 et retournées horizontalement (miroir X), sans inverser la chronologie.
Canvas identique : 768x512 par frame ; même nom/chemin pour un raccord direct. Tous les autres sprites et les 5 icônes sont conservés.
Ces PNG sont prêts à être raccordés, mais cette archive seule ne modifie pas les fichiers GitHub du jeu.
